'use server';

export async function getSubscriptionStatus() {
  // Existing getSubscriptionStatus implementation
}

export async function createCheckoutSession(priceId: string) {
  void priceId
  // Existing createCheckoutSession implementation
}

export async function cancelSubscription() {
  // Existing cancelSubscription implementation
} 