'use client'

export default function Error() {
  return <p>Sorry, something went wrong</p>
}