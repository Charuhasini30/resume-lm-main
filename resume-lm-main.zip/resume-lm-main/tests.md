Areas that need to be tested



# Authentication
- Account Creation
- Sign up with Github

- Account Login
- Log in with github

- Password recovery
- account recovery


AI Actions
- Fetching Resumes 